# AmplifyJS, A JavaScript Component Library

AmplifyJS is a set of components for data management and application communication.

For more information or a distribution with minified files see the [AmplifyJS site](http://amplifyjs.com).

## Documentation

Documentation is available online in the [AmplifyJS API site](http://amplifyjs.com/api/request/) and it is also included in each  of the component directories. Documentation includes both usage information and examples.

## TestSwarm

Testswarm is available at [http://swarm.amplifyjs.com](http://swarm.amplifyjs.com)
