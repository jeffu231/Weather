define(['app/model.viewmodel-config-function'], function(vmCfgFunc){
	
	var viewModelConfig = 
		{
			currentconditions: {
				containerId: "current-conditions"
			}
		};
	
	return viewModelConfig;
});