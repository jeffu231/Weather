define(['jquery', 'knockout'], function($, ko){
	
	function apply() {
		ko.bindingHandlers.secondsCounter = {
				update: function(element, valueAccessor){
					
					
				}
		};
	};
	
	return apply;
});